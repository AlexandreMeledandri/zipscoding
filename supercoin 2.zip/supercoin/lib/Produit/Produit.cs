﻿using System;

namespace Produit
{
    public abstract class Produit
    {
        public String Nom{get;set;}
        public int Prix{get;set;}
        public String Ville{get;set;}

        public virtual void pouet(){
            Console.WriteLine("HELLO");
        }
        public String[] Images = new String[2];
    }
}
