﻿using System;

namespace Produit.Vetement
{
    public class Vetement : Produit
    {
        private String _taille;
        private String _couleur;
    }
}
