﻿using System;

namespace Produit.Vehicule
{
    public class Vehicule : Produit
    {
        private int _kilometrage;
        private int _puissance;

        public override void pouet(){
            base.pouet();
            Console.WriteLine("POUUUEETT");
        }
    }
}
