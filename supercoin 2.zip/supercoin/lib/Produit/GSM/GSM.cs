﻿using System;

namespace Produit.GSM
{
    public class GSM : Produit{
        private int _autonomie;
        public int Autonomie{
            get {
                var autonomie = _autonomie * 100;
                return autonomie;}
            set{_autonomie = value;}
        }
        public int Stockage{get;set;}
        
    }
    }
