﻿using System;

namespace MenuPrincipal
{
    public class Class1
    {
    }
}
