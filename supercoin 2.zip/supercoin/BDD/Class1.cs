﻿using System;

namespace BDD
{
    public class Class1
    {
    }
}
