﻿using System;
using Produit.Vehicule;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace src
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.Beep();
        }
    }
}
