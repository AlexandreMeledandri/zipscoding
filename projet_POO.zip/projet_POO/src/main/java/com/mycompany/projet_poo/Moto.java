/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projet_poo;

/**
 *
 * @author alexandremeledandri
 */
public class Moto extends Vehicule{ //moto est une classe fille de Vehicule
    public Moto ( boolean _sidecar,int _kmhMax){ //ici je définis un constructeur qui permettra de donner des valeurs aux membres de la classe lors de l'instanciation
        sidecar = _sidecar;
        kmhMax = _kmhMax;
    }
    private boolean sidecar;
    private int kmhMax;
    //ci dessous, je définis des "getters" qui me permettront d'acceder à la valeur de mes propriétés déclarées comme privées dans ma classe
    public boolean getSidecar(){
        return this.sidecar;
    }
    public int getKmhMax(){
        return this.kmhMax;
    }
    public String organe_de_direction = "Guidon"; // je surcharge la propriété déclarée dans Vehicule
    public void wheelie (){
            System.out.println("Vous faites un wheelie.");
        }
}
