/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projet_poo;

/**
 *
 * @author alexandremeledandri
 */
        public class Voiture extends Vehicule{ // Je déclare ma classe Voiture qui hérite de la classe Vehicule
        public boolean isClim;
        public String organe_de_direction = "Volant";
        public void freinAMain (){
            System.out.println("Vous declenchez le frein à main.");
        }
        }
