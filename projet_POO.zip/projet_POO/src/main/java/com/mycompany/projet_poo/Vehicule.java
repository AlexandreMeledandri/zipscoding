/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projet_poo;

/**
 *
 * @author alexandremeledandri
 */
//Ci-dessous je déclare une classe abstraitre, non instaciable
public abstract class Vehicule implements MethodesMotorisees{ //elle implémente une interface, je devrai donc les déclarer
    //Ci-dessous, je déclare mes membres, à commencer par les propriétés (variables) de ma classe
        public int nombre_roues;
        public String motorisation;
        public String organe_de_direction = null;
        private final int KILOMETRE = 100; //Cet attribut étant privé à la classe et sa valeur fixée, on peut en faire une constante
        //Ci -dessous, je déclare une fonction qui appelera un attribut privé à la classe
        @Override // @override est une bonne pratique, il précise juste au développeur que nous allons surcharger une méthode
        public float calculConsoCent(float consommation){
            float conso = (consommation * KILOMETRE);
            return conso;
        }
        //Ci-dessous, je déclare une méthode de classe (fonctions) puis je la surcharge
        @Override
        public void contactAllume (String value){
            System.out.println(value);
        }
        @Override
        public void contactAllume(boolean contactEstAllume){
            if(contactEstAllume == true){
                System.out.println("Le contact est bien allume");
            } else if (contactEstAllume == false){
                System.out.println("Le contact est eteint");
            }
        }
        public void welcomeMessage (){
            System.out.println("Bienvenue dans ce véhicule");
        }
}
