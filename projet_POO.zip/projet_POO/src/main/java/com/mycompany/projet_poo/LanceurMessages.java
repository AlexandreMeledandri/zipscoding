/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projet_poo;

/**
 *
 * @author alexandremeledandri
 */
//Ci-dessous, je déclare une classe qui appelera des méthodes d'affichage de message
public class LanceurMessages {
    //Ci-dessous, je déclare une méthode qui attend un objet Vehicule en parametre lors de l'appel
     //Ici le passage du type Vehicule devant vehiculeTeste upcast implicitement l'objet de classe fille en type Voiture
    public void message(Vehicule vehiculeTeste){
        vehiculeTeste.welcomeMessage(); //Ainsi, je peux appeler la méthode de classe-mère sur n'importe quel objet de classe fille passé en parametre
    // Ci-dessous je teste si l'objet passé en parametre est une instance d'une classe-fille en particulier
     if (vehiculeTeste instanceof Voiture) {
        Voiture voiture = (Voiture) vehiculeTeste; //Ici, je downcast mon objet précédement upcasté pour qu'il retrouve son type Voiture
        voiture.freinAMain(); //je peux de nouveau appeler sa méthode qui n'existe pas dans sa classe mère
        //Ci-dessous je réitire l'opération avec un objet de classe Moto, autre classe fille de Véhicule
    } else if (vehiculeTeste instanceof Moto) {
        Moto moto = (Moto) vehiculeTeste;
        moto.wheelie();//Ici, j'appelle sa méthode déclarée dans la classe Moto
    }
    }

}
