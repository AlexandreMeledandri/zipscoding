/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projet_poo;

/**
 *
 * @author alexandremeledandri
 */
public interface MethodesMotorisees {
    //Ci -dessous, je déclare mes méthodes qui seront implémentées dans les classes nécessitant cette interface
        public float calculConsoCent(float consommation);
        public void contactAllume(String Value);
        public void contactAllume(boolean contactEstAllume);
        public default void coucou(){
            System.out.println("coucou!!!");
        }
}
