/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package echecs_netbeans;

/**
 *
 * @author alexandremeledandri
 */


public class MainClass { // Je déclare ma classe. En Java, le nom du fichier est le meme que la classe principale

    //Dans mon main je vais instancier ma classe voiture et assigner des valeurs à ses propriétés
    public static void main (String[]args){
    Voiture clio = new Voiture(); //J'instancie un nouvel objet à partir de ma classe Voiture
    clio.nombre_roues = 4; // J'assigne une valeur à la propriété roues de mon objet clio
    System.out.println(clio.nombre_roues // ici je fais un print dans la console de la propriété nombre_roues
    );
    //Ci-desssous, j'appelle mes méthodes de classe avec les valeurs attendues en parametre
    clio.contactAllume("Le contact est-il allumé?");
    clio.contactAllume(true);
    clio.contactAllume(false);
    //Ci-dessous, je print une méthode protected de la classe mère Vehicule
    System.out.println(clio.calculConsoCent(0.02f));
    //Ci-dessous, j'affiche une propriété déclarée dans la classe mère et surchargée dans la classe fille
    System.out.println(clio.organe_de_direction);
    //Ci-dessous, je teste si l'objet clio est une instance de la classe Voiture puis véhicule et je print si c'est le cas
    if(clio instanceof Voiture){
        System.out.println("clio est une instance de la classe Voiture");
    }
    
    LanceurMessages lanceur = new LanceurMessages(); //j'instancie un nouvel objet LanceurMessages
    lanceur.message(clio); //je passe à la méthode message l'objet clio de type Voiture
    Moto suzuki = new Moto(true,200);
    lanceur.message(suzuki); //je passe à la méthode message l'objet clio de type Moto
    System.out.println(suzuki.getKmhMax());
    clio.coucou();
    
    clio = null; // je passe la valeur null a ma variable pour faire passer le Garbage Collector
    
    
    }
    
}
