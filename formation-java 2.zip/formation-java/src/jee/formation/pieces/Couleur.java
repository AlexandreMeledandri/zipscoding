package jee.formation.pieces;

public enum Couleur { NOIR, BLANC }
