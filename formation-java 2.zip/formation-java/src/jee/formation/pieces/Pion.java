package jee.formation.pieces;

import java.util.ArrayList;
import java.util.List;

public class Pion extends Piece {
	public static Pion BLANC = new Pion(Couleur.BLANC);
	public static Pion NOIR = new Pion(Couleur.NOIR);
	
	private Pion(Couleur couleur) {
		super(couleur);
	}

	@Override
	List<Coordonnees> deplacementsValides(Coordonnees origine) {
		final ArrayList<Coordonnees> result = new ArrayList<>();
		
		int lastY;
		int direction;
		if (getCouleur() == Couleur.BLANC) {
			lastY = 0;
			direction = -1;
		} else {
			lastY = 7;
			direction = 1;
		}
		
		if (origine.getY() != lastY) {
			result.add(new Coordonnees(origine.getX(), origine.getY() + direction));
		}
		
		return result;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*final List<Coordonnees> result = new ArrayList<>();
		
		int lastY;
		int direction;
		if (getCouleur() == Couleur.BLANC) {
			lastY = 0;
			direction = -1;
		} else {
			lastY = 7;
			direction = 1;
		}
		
		if (origine.getY() != lastY) {
			result.add(new Coordonnees(origine.getX(), origine.getY() + direction));
		}
		return result;*/
	}
}
