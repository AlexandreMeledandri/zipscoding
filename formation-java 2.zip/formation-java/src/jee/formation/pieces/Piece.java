package jee.formation.pieces;

import java.util.List;

public abstract class Piece {
	private final Couleur couleur;
	
	protected Piece(Couleur couleur) {
		this.couleur = couleur;
	}
	
	protected boolean isInside(int x, int y) {
		return ( x >= 0 && x < 8 && y >= 0 && y < 8 );
	}
	
	public abstract List<Coordonnees> deplacementsValides(Coordonnees origine);
	public Couleur getCouleur() { return couleur; }
}