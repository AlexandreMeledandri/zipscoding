package jee.formation;

public class Personne {
	String nom;
	
	Personne(String name) {
		nom = name;
	}
	
	public static void main(String[] args) {
		Personne personne = new Personne(args[0]);
		System.out.println(personne);
	}
	
	@Override
	public String toString() {
		return nom;
	}
}