package jee.formation.interfaces;

interface Brulable {
	void onBrule();
}

interface Frappable {
	void onFrappe();
}

class Arme implements Frappable {
	@Override
	public void onFrappe() {
		System.out.println("ouille ouille ouille");
	}
}

class Epee extends Arme {
	
}

class Baton extends Arme implements Brulable {
	@Override
	public void onBrule() {
		System.out.println("Oh, c'est chaud !");
	}
}

class Main {
	public void main(String[] args) {
		new Epee().onFrappe();
		new Baton().onBrule();
	}
}