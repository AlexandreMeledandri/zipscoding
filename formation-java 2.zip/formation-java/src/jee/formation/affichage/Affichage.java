package jee.formation.affichage;

import jee.formation.pieces.Coordonnees;
import jee.formation.pieces.Couleur;
import jee.formation.pieces.Piece;
import jee.formation.pieces.Pion;
import jee.formation.pieces.Roi;
import jee.formation.plateau.Echiquier;

public class Affichage {
	public static void main(String[] args) {
		final Echiquier echiquier = new Echiquier();
		
		for (int y = 0; y < 8; y++) {
			String line = "";
			
			for (int x = 0; x < 8; x++) {
				final Piece piece = echiquier.getPieceEn(new Coordonnees(x, y));
				String representation = (piece == null) ? "--" : asString(piece);
				line = line + " " + representation;
			}
			
			System.out.println(line);
		}
	}
	
	private static String asString(Piece piece) {
		String p;
		String c = asString(piece.getCouleur());
		
		if (piece instanceof Pion) {
			p = "P";
		} else if (piece instanceof Roi) {
			p = "K";
		} else {
			return null;
		}
		return p + c;
	}
	private static String asString(Couleur couleur) {
		return couleur == Couleur.BLANC ? "b" : "n";
	}
}
