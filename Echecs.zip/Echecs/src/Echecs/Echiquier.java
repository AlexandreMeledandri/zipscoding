package Echecs;

import java.util.List;

public class Echiquier {
	private Piece[][] plateau = {//new Piece[8][8]; // [y][x]
			{ null, null, null, Roi.NOIR, null, null, null, null },
			{ Pion.NOIR, Pion.NOIR, Pion.NOIR, Pion.NOIR, Pion.NOIR, Pion.NOIR, Pion.NOIR, Pion.NOIR },
			{ null, null, null, null, null, null, null, null },
			{ null, null, null, null, null, null, null, null },
			{ null, null, null, null, null, null, null, null },
			{ null, null, null, null, null, null, null, null },
			{ Pion.BLANC, Pion.BLANC, Pion.BLANC, Pion.BLANC, Pion.BLANC, Pion.BLANC, Pion.BLANC, Pion.BLANC },
			{ null, null, null, Roi.BLANC, null, null, null, null }
	};
	
	public Piece getPieceEn(Coordonnees coords) {
		return plateau[coords.getY()][coords.getX()];
	}
	
	public boolean moveTo(Coordonnees origine, Coordonnees destination) {
		final Piece pieceABouger = getPieceEn(origine);
		
		if (pieceABouger == null) {
			return false;
		}
		
		List<Coordonnees> possibles = pieceABouger.deplacementsValides(origine);
		
		// for (int i = 0; i < possibles.size(); i++) { Coordonnees actual = possibles.get(i); ... }
		for(Coordonnees actual : possibles) {
			if (actual.equals(destination)) {
				// Le d�placement est valide
				plateau[destination.getY()][destination.getX()] = pieceABouger;
				plateau[origine.getY()][origine.getX()] = null;
				return true;
			}
		}
		return false;
	}
}
