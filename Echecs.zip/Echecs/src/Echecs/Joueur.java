package Echecs;

public class Joueur {

}
