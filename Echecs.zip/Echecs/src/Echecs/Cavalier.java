package Echecs;

import java.util.List;

public class Cavalier extends Piece {
	public Cavalier (Couleur couleur) {
		super(couleur);
	}
	
	List<Coordonnees> deplacementsValides(Coordonnees origine) {
		return null;
	}
}