package Echecs;

import java.util.List;

public class Tour extends Piece {
	public Tour (Couleur couleur) {
		super(couleur);
	}
	
	List<Coordonnees> deplacementsValides(Coordonnees origine) {
		return null;
	}
}
