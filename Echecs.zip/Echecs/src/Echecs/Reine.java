package Echecs;

import java.util.List;

public class Reine extends Piece {
	public Reine (Couleur couleur) {
		super(couleur);
	}
	
	List<Coordonnees> deplacementsValides(Coordonnees origine) {
		return null;
	}
}