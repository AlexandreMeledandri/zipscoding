package Echecs;

public interface Clic {

}
