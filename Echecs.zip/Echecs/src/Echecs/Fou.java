package Echecs;

import java.util.List;

public class Fou extends Piece{
	
	/*gestion des déplacements du fou
	void deplacement(int chiffre, int lettre) {
		
		// verification que les parametres passees soient valides
		if(chiffre <= 8 && chiffre > 0) {
			//le parametre passé modifie la valeur de la propriété positionChiffre de l'objet
			this.positionChiffre = chiffre; 
		}else {
			//sinon, un message d'erreur est retourné
			System.out.println("déplacement invalide."); 
		} if(lettre <= 8 && lettre > 0) {
			this.positionLettre = lettre;
		}else {
			System.out.println("déplacement invalide.");
		}
	}*/

	public Fou (Couleur couleur) {
		super(couleur);
	}
	
	List<Coordonnees> deplacementsValides(Coordonnees origine) {
		return null;
	}
}
