 #! /bin/bash
cd ~/Desktop/Tesla/src
javac -d ../bin/ test/Homepage/*.java
cd ../bin/
java org.junit.runner.JUnitCore test.homepage.TeslaTest
