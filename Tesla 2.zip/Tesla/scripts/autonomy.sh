 #! /bin/bash
cd ~/Desktop/Tesla/src
javac -d ../bin/ test/autonomy/*.java
cd ../bin/
java org.junit.runner.JUnitCore test.autonomy.TeslaAutonomyTest
