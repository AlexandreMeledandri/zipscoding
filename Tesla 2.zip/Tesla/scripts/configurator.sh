 #! /bin/bash
cd ~/Desktop/Tesla/src
javac -d ../bin/ test/configurator/*.java
cd ../bin/
java org.junit.runner.JUnitCore test.configurator.TeslaConfiguratorTest
