#! /bin/bash
cd ~/Desktop/Tesla/src
javac -d ../bin/ test/events/*.java
cd ../bin/
java org.junit.runner.JUnitCore test.events.TeslaEventsTest
