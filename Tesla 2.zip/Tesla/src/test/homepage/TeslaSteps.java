package test.homepage;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import static org.junit.Assert.*;

import static org.hamcrest.Matchers.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;

// Story 1
public class TeslaSteps {

	public static WebDriver driver;

	@Before
	public void beforeScenario() 
	{
		System.setProperty("webdriver.chrome.driver","/Library/Java/JUNIT/chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@Given("^je suis sur la homepage$")
	public void je_suis_sur_la_homepage() throws Throwable
	{
		driver.get("https://www.tesla.com/fr_FR/");
	}

	@Then("^le titre doit être \"([^\"]*)\"$")
	public void le_titre_doit_être(String arg1) throws Throwable
	{
		assertEquals(driver.getTitle(), arg1);
	}

	@Then("^le texte doit être \"([^\"]*)\"$")
	public void le_texte_doit_être(String arg1) throws Throwable
	{
		assertEquals(driver.findElement(By.cssSelector("h1.section-title--hed.hide-on-mobile")).getText().replace("\n"," "), arg1);
	}

	@Then("^le bouton ne doit pas être null$")
	public void le_bouton_ne_doit_pas_être_null() throws Throwable 
	{
    	assertNotSame(driver.findElement(By.cssSelector("a.btn.btn-large.btn-transparent.hide-on-mobile.hide-on-variant-2")), null);
	}

	@Then("^le titre du bouton doit être \"([^\"]*)\"$")
	public void le_titre_du_bouton_doit_être(String arg1) throws Throwable 
	{
    	assertEquals(driver.findElement(By.cssSelector("a.btn.btn-large.btn-transparent.hide-on-mobile.hide-on-variant-2")).getText(), arg1);
	}


	@After
	public void afterScenario() 
	{
		driver.quit();
	}

}