package test.configurator;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	features = {"../src/test/configurator"}, // ou se situe votre fichier .feature
	plugin = {"pretty"}
	)
public class TeslaConfiguratorTest {

}